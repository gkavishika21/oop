package com.acteno.servelets;

import java.io.IOException;

import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Statement;

import Basic.define;
import util.DataBaseConnnection;


@WebServlet("/customer_issues")
public class customer_issues extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public customer_issues() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
		String issues_type = request.getParameter("issues");
		String cname       = request.getParameter("cname");
		String email       = request.getParameter("email");
		String description = request.getParameter("description");
		
		String sql = "INSERT INTO cusissues(customer_name, email, issue_type, description) VALUES('"+cname+"', '"+email+"', '"+issues_type+"', '"+description+"')";
		
		try {
			Connection conn;
			Statement pstmnt = null;
			
			conn = DataBaseConnnection.getConnection();
			pstmnt = (Statement) conn.createStatement();
			pstmnt.executeUpdate(sql);
			
			System.out.println("Done !");
			
			response.sendRedirect("Gproject.jsp");
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
	}

}

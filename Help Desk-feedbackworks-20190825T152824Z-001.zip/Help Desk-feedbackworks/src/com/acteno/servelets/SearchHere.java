package com.acteno.servelets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Statement;

import util.DataBaseConnnection;

/**
 * Servlet implementation class SearchHere
 */
@WebServlet("/SearchHere")
public class SearchHere extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchHere() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String search = request.getParameter("search");
		
		if(search.equals("charge")) {
			response.sendRedirect("faq.jsp#f1");
		}
		else if (search.equals("reset")) {
			response.sendRedirect("faq.jsp#f2");
		}
	}
	
	   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String search = request.getParameter("search");
		
		if (search.equals("phones")) {
				
			Connection conn;
			Statement pstmnt = null;
			String val1 = null;
			String val2 = null;
			
			try{
				conn = DataBaseConnnection.getConnection();
				pstmnt = (Statement) conn.createStatement();
				ResultSet result = pstmnt.executeQuery("SELECT * FROM phones");
				
				while(result.next()){
					
				
						result.getString(1);
						result.getString(2);
					
				}
			}
			catch(SQLException e){
				
				System.out.println(e);
			}
			
			System.out.println(val1);
			System.out.println(val2);
		}
	}



}

package Basic;

import java.util.ArrayList;


public interface Phone {
	public ArrayList<Phone> getPhone();

}

package Basic;

import java.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;

import util.DataBaseConnnection;

public class PhoneInfo implements Phone{

	@Override
	public ArrayList<Phone> getPhone() {
		// TODO Auto-generated method stub
		ArrayList<Phone> phonesList = new ArrayList<Phone>();
		
		try {
			Connection conn;
			Statement pstmnt = null;
			
			conn = DataBaseConnnection.getConnection();
			
			PreparedStatement myStmt = conn.prepareStatement("SELECT  * FROM phones");
			
			ResultSet resultSet = myStmt.executeQuery();
			
	
			
		}catch(Exception  e) {
			System.out.println("Exception : " + e );
		}
		
		return phonesList;
	}

}

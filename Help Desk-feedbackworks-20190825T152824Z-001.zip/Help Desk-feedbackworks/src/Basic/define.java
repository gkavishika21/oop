package Basic;



public class define {
	
	private static String prefix="P100";
	private static int iter=1;
	private String id ;
	private String firstname;
	private String emailaddress;
	private String place;
	private String service;
	private String suggestions;
	
	public void setid(String id) {
		this.id = id;
	}
	public String getid() {
		return id;
	}
	public void generateid() {
		this.id = define.prefix + define.iter;
		define.iter++;
	}
	public String getfirstname() {
		return firstname;
	}
	public void setfirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getemailaddress() {
		return emailaddress;
	}
	public void setemailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}
	public String getplace() {
		return place;
	}
	public void setplace(String place) {
		this.place = place;
	}
	public String getservice() {
		return service;
	}
	public void setservice(String service) {
		this.service = service;
	}
	public String getsuggestions() {
		return suggestions;
	}
	public void setsuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
	
	
}
package  customer ;


import java.util.ArrayList;

import Basic.define;

public interface view {
	
	/*
	 * add feedback details 
	 */
	public void addFeedbackDetails(define fdetails);
	
	public void getFeedback();
                 
	
		
		
		
		
}
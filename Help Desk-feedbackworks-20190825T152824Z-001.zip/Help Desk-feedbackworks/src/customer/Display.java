package customer;

import java.sql.Connection;
import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;

import Basic.define;
import util.DataBaseConnnection;


public class Display  implements view {

	Connection conn;
	PreparedStatement prepare;
	
	
	@Override
	public void addFeedbackDetails(define fdetails) {
		try {
			conn = DataBaseConnnection.getConnection();
			
		
			prepare=conn.prepareStatement("insert into feedback values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			prepare.setString(1, fdetails.getid());
			prepare.setString(2, fdetails.getfirstname());
			prepare.setString(3, fdetails.getemailaddress());
			prepare.setString(4, fdetails.getplace());
			prepare.setString(5, fdetails.getservice());
			prepare.setString(6, fdetails.getsuggestions());
			
			
			prepare.executeUpdate();
					
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
            if (conn != null) {
                try {
                    conn.close();
                    System.out.println("Database Connection Terminated");
                } catch (Exception e) {}
            }
		}

	}
	public void getFeedback(){
		try {
			conn = DataBaseConnnection.getConnection();
			
			prepare = conn.prepareStatement("select * from feedback");
			
			
			ResultSet resultSet = prepare.executeQuery();
			
			while(resultSet.next()){
				
                
                                                                 String firstname = resultSet.getString("firstname");
		                              String emailaddress = resultSet.getString("emailaddress");
		                              String place = resultSet.getString("place");
			            Date service = resultSet.getDate("service");
			            String suggestions = resultSet.getString("suggestions");
			}	
				
		} 
		catch(Exception e) {
			e.printStackTrace();
		} 
		finally {
			if (conn != null) {
				try {
					conn.close();
					System.out.println("Database Connection Terminated.");
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

		
	
	
	
	
		
}